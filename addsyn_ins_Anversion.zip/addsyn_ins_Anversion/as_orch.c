initial()
{
	ADDSYN_init("Addsyn", 10);
}
